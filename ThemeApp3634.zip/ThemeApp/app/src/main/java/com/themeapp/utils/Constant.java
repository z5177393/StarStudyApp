package com.themeapp.utils;

public class Constant {
    public static String basrurl  ="https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY";
}
